﻿using Abp.Application.Services.Dto;

namespace HospitalManagement.Business.Roles.Dto
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

