const URL = process.env.NODE_ENV === 'production' ? 'https://yourdomain/' : 'https://localhost:44311/';
export default URL;