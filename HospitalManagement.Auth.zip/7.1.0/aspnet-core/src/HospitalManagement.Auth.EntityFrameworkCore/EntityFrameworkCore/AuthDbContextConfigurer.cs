using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace HospitalManagement.Auth.EntityFrameworkCore
{
    public static class AuthDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<AuthDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<AuthDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
